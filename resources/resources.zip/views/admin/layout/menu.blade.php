<!-- Menu -->
@php
    use App\Models\Setting;
@endphp
<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">


    <div class="app-brand demo ">
        <a href="{{ route('home') }}" class="app-brand-link">
            <span class="app-brand-logo demo">

                <img style="width: 45px; height:auto"
                    src="{{ asset('images') }}/{{ Setting::find(1)->photo != null ? Setting::find(1)->photo : 'no-image.png' }}"
                    class="  ms-auto" alt="logo" width="30" />
            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2">{{ Setting::find(1)->name }}</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>



    <ul class="menu-inner py-1">

        {{-- ################################################Home################################################################### --}}
        {{-- @can('view dashboard') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'home' ? 'active open' : '' }} ">
            <a href="{{ route('home') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bxs-home "></i>
                <div class="text-truncate">{!! __('admin.Dashboards') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}

        {{-- ################################################End Home################################################################### --}}


        {{-- ################################################booking################################################################### --}}

        {{-- @can('view booking') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'booking.index' ? 'active open' : '' }} ">
            <a href="{{ route('booking.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-calendar'></i>

                <div class="text-truncate"> {!! __('admin.Bookings') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################End booking################################################################### --}}

        {{-- ################################################Expenses################################################################### --}}

        <li class="menu-item   {{ Request::route()->getName() == 'expenses.index' ? 'active open' : '' }}">
            <a href="{{ route('expenses.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bx-money'></i>
                <div class="text-truncate">{!! __('admin.Expenses') !!}</div>
            </a>
        </li>

        {{-- ################################################End Expenses################################################################### --}}
        {{-- ################################################meeting################################################################### --}}

        {{-- @can('view meeting') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'meeting.index' ? 'active open' : '' }} ">
            <a href="{{ route('meeting.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-video'></i>

                <div class="text-truncate">{!! __('admin.Meetings') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################End meeting################################################################### --}}

        {{-- ################################################contact################################################################### --}}

        {{-- @can('view contact') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'contact.index' ? 'active open' : '' }} ">
            <a href="{{ route('contact.index') }}" class="menu-link">

                <i class='menu-icon tf-icons bx bxs-chat'></i>
                <div class="text-truncate">{!! __('admin.Contact Us') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################ End contact################################################################### --}}


        {{-- ############################## Customers & Groups Dropdown ################################# --}}
        <li
            class="menu-item {{ in_array(Request::route()->getName(), ['customer.index', 'group.index']) ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class='menu-icon tf-icons bx bxs-user-detail'></i>
                <div class="text-truncate">{{ __('admin.Customers') }}</div>
            </a>
            <ul class="menu-sub">
                {{-- Customers --}}
                <li class="menu-item {{ Request::route()->getName() == 'customer.index' ? 'active' : '' }}">
                    <a href="{{ route('customer.index') }}" class="menu-link">
                        <div class="text-truncate">{{ __('admin.Customers') }}</div>
                    </a>
                </li>

                {{-- Groups --}}
                <li class="menu-item {{ Request::route()->getName() == 'group.index' ? 'active' : '' }}">
                    <a href="{{ route('group.index') }}" class="menu-link">
                        <div class="text-truncate">{{ __('admin.Groups') }}</div>
                    </a>
                </li>
            </ul>
        </li>
        {{-- ############################## End Customers & Groups Dropdown ################################# --}}

        {{-- ################################################visit################################################################### --}}

        <li class="menu-item   {{ Request::route()->getName() == 'visit.index' ? 'active open' : '' }}">
            <a href="{{ route('visit.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-plane-alt'></i>

                <div class="text-truncate">{!! __('admin.Visits') !!}</div>
            </a>
        </li>

        {{-- ################################################End visit################################################################### --}}




        {{-- ###################### Education Section Dropdown ###################### --}}
        <li
            class="menu-item {{ in_array(Request::route()->getName(), ['teachers.index', 'lecture.index', 'employees.index', 'exam.index']) ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class='menu-icon tf-icons bx bxs-user'></i>
                <div class="text-truncate">{{ __('admin.Employees') }}</div>
            </a>
            <ul class="menu-sub">
                {{-- Teachers --}}
                <li class="menu-item {{ Request::route()->getName() == 'teachers.index' ? 'active' : '' }}">
                    <a href="{{ route('teachers.index') }}" class="menu-link">

                        <div class="text-truncate">{{ __('admin.Teachers') }}</div>
                    </a>
                </li>

                {{-- Employees --}}
                <li class="menu-item {{ Request::route()->getName() == 'employees.index' ? 'active' : '' }}">
                    <a href="{{ route('employees.index') }}" class="menu-link">

                        <div class="text-truncate">{{ __('admin.Employees') }}</div>
                    </a>
                </li>

                {{-- Lectures --}}
                <li class="menu-item {{ Request::route()->getName() == 'lecture.index' ? 'active' : '' }}">
                    <a href="{{ route('lecture.index') }}" class="menu-link">

                        <div class="text-truncate">{{ __('admin.Lectures') }}</div>
                    </a>
                </li>

                {{-- Exams --}}
                <li class="menu-item {{ Request::route()->getName() == 'exam.index' ? 'active' : '' }}">
                    <a href="{{ route('exam.index') }}" class="menu-link">

                        <div class="text-truncate">{{ __('admin.Exam') }}</div>
                    </a>
                </li>
            </ul>
        </li>
        {{-- ###################### End Education Section Dropdown ###################### --}}


        {{-- ################################################roles################################################################### --}}

        {{-- @can('view role') --}}
        {{-- <li class="menu-item   {{ Request::route()->getName() == 'roles.index' ? 'active open' : '' }}">
            <a href="{{ route('roles.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-id-card'></i>
                <div class="text-truncate">{!! __('admin.Roles') !!}</div>
            </a>
        </li> --}}
        {{-- @endcan --}}
        {{-- ################################################End roles################################################################### --}}

        {{-- ################################################courses################################################################### --}}


        {{-- @can('view course') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'courses.index' ? 'active open' : '' }} ">
            <a href="{{ route('courses.index') }}" class="menu-link">

                <i class='menu-icon tf-icons bx bxs-carousel'></i>
                <div class="text-truncate">{!! __('admin.Online Sessions') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################End courses################################################################### --}}





        {{-- ################################################Reviews################################################################### --}}


        {{-- @can('view review') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'courses_review.index' ? 'active open' : '' }} ">
            <a href="{{ route('courses_review.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-star'></i>

                <div class="text-truncate">{!! __('admin.Reviews') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################End Reviews################################################################### --}}


        {{-- ################################################subscribe################################################################### --}}

        {{-- @can('view subscribe') --}}
        {{-- <li class="menu-item  {{ Request::route()->getName() == 'subscribe.index' ? 'active open' : '' }} ">
            <a href="{{ route('subscribe.index') }}" class="menu-link">

                <i class='menu-icon tf-icons bx bxs-bell-ring'></i>
                <div class="text-truncate">{!! __('admin.Subscribe') !!}</div>
            </a>
        </li> --}}
        {{-- @endcan --}}


        {{-- ################################################End subscribe################################################################### --}}




        {{-- ###################### Blogs ###################### --}}
        <li
            class="menu-item {{ in_array(Request::route()->getName(), ['blog.index', 'blog_category.index']) ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">

                <i class='menu-icon tf-icons bx bxs-book'></i>
                <div class="text-truncate">{{ __('admin.Blogs') }}</div>
            </a>
            <ul class="menu-sub">
                {{-- Teachers --}}
                <li class="menu-item {{ Request::route()->getName() == 'blog.index' ? 'active' : '' }}">
                    <a href="{{ route('blog.index') }}" class="menu-link">

                        <div class="text-truncate">{!! __('admin.Blogs') !!}</div>
                    </a>
                </li>

                {{-- Lectures --}}
                <li class="menu-item {{ Request::route()->getName() == 'blog_category.index' ? 'active' : '' }}">
                    <a href="{{ route('blog_category.index') }}" class="menu-link">

                        <div class="text-truncate">{!! __('admin.Blog Categores') !!}</div>
                    </a>
                </li>


            </ul>
        </li>
        {{-- ###################### End Blogs ###################### --}}



        {{-- ################################################rateing################################################################### --}}

        {{-- @can('view rating') --}}
        {{-- <li class="menu-item  {{ Request::route()->getName() == 'rateing.index' ? 'active open' : '' }} ">
            <a href="{{ route('rateing.index') }}" class="menu-link">
                <i class='menu-icon tf-icons bx bxs-book'></i>

                <div class="text-truncate">{!! __('admin.Rateing') !!}</div>
            </a>
        </li> --}}
        {{-- @endcan --}}
        {{-- ################################################End rateing################################################################### --}}



        {{-- ################################################slider################################################################### --}}

        {{-- @can('view setting') --}}
        <li class="menu-item  {{ Request::route()->getName() == 'slider.index' ? 'active open' : '' }} ">
            <a href="{{ route('slider.index') }}" class="menu-link">

                <i class='menu-icon tf-icons bx bxs-cog'></i>
                <div class="text-truncate">{!! __('admin.Settings') !!}</div>
            </a>
        </li>
        {{-- @endcan --}}
        {{-- ################################################End slider################################################################### --}}









    </ul>
    </li>
    <!-- Products end -->





    </ul>



</aside>
<!-- / Menu -->
